package com.tidyjava.bp.post;

class MissingPostException extends RuntimeException {
}
