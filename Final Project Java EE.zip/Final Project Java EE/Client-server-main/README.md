# Client-server
client server

# Flyway usage
Add and configure flyway with create/insert
