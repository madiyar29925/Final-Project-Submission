INSERT INTO test_demo_db.users (name, age) VALUES ('New name', 50);
INSERT INTO test_demo_db.users (name, age) VALUES ('Bobby', 40);
INSERT INTO test_demo_db.users (name, age) VALUES ('Tommy', 50);
INSERT INTO test_demo_db.users (name, age) VALUES ('Frank', 20);
INSERT INTO test_demo_db.users (name, age) VALUES ('Jim', 30);
INSERT INTO test_demo_db.users (name, age) VALUES ('Tommy', 20);
INSERT INTO test_demo_db.users (name, age) VALUES ('New User', 50);