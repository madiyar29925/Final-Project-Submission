INSERT into customer (name) VALUES
('Hello Customer 1'),
('Customer 2');