INSERT INTO test_demo_db.course (title) VALUES ('Java');
INSERT INTO test_demo_db.course (title) VALUES ('Databases');