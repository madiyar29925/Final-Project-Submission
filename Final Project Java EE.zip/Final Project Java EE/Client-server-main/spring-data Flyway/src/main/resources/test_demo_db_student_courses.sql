INSERT INTO test_demo_db.student_courses (student_id, course_id) VALUES (1, 1);
INSERT INTO test_demo_db.student_courses (student_id, course_id) VALUES (1, 2);