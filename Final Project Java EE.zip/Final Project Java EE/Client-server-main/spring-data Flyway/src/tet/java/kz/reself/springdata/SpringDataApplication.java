package kz.reself.springdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataApplication {

	@Test
	void contextLoads() {
	}

}
