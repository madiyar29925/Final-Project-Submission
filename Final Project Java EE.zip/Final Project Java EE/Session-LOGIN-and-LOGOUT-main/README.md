# Session-LOGIN-and-LOGOUT
Read and try all of sections (Session Tracking - Session Techniques: 1) Cookies in Servlet; Cookies: Login &amp; Logout 2) Hidden Form Field, 3) URL Rewriting; 4) HttpSession and Session: Login &amp; Logout)
