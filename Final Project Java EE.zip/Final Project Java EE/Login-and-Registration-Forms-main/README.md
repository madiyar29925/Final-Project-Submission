# Login-and-Registration-Forms
Create an Application to handle Login and Registration forms using Java Servlets
